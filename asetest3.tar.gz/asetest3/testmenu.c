#include <stdio.h>
#include <stdlib.h>
#include "menu.h"

#define FUNC_NUM	8
#define RESULT_NUM	8
#define debug 

static char * info[FUNC_NUM+1] = 
{
	"TC List :" ,
	"TC1: CreateMenu",
	"TC2: AddCmd",
	"TC3: DelCmd",
	"TC4: MenuStart",
	"TC5: DeleteMenu",
	"TC6: ShowAllCmd",
	"TC7: FindCmd",
	"TC8: RunCmdHander"
};

static int result[RESULT_NUM];

int main()
{
	int temp = 0;
	char * cmd = "l";
	char * desc = "d";
	int j;
	tCmdNode * pNode;
	/*
	 * test CreateMenu
	 */
	tLinkTable * pMenu = CreateMenu();
	if(pMenu == NULL)
	{
		debug("error : CreateMenu is failure !\n");
		result[1] = 0;
	}
	else
	{
		debug("CreateMenu is success !\n");
		result[1] = 1;
	}
	/*
	 * test AddCmd
	 */
	temp = AddCmd(pMenu, cmd, desc);
	if(temp == FAILURE)
	{
		debug("error : AddCmd is failure !\n");
		result[2] = 0;
	}
	else
	{
		debug("AddCmd is success !\n");
		result[2] = 1;
	}
	/*
	 * test DelCmd
	 */
	temp = DelCmd(pMenu, cmd);
	if(temp == FAILURE)
	{
		debug("error : DelCmd is failure !\n");
		result[3] = 0;
	}
	else
	{
		debug("DelCmd is success !\n");
		result[3] = 1;
	}
	/*
	 * test MenuStart
	 */
	temp = MenuStart(pMenu);
	if(temp == FAILURE)
	{
		debug("error : MenuStart is failure !\n");
		result[4] = 0;
	}
	else
	{
		debug("MenuStart is success !\n");
		result[4] = 1;
	}
	/*
	 * test DeleteMenu
	 */
	temp = DeleteMenu(pMenu);
	if(temp == FAILURE)
	{
		debug("error : DeleteMenu is failure !\n");
		result[5] = 0;
	}
	else
	{
		debug("DeleteMenu is success !\n");
		result[5] = 1;
	}
	/*
	 * test ShowAllCmd
	 */
	temp = ShowAllCmd(pMenu);
	if(temp == FAILURE)
	{
		debug("error : ShowAllCmd is failure !\n");
		result[6] = 0;
	}
	else
	{
		debug("ShowAllCmd is success !\n");
		result[6] = 1;
	}
	/*
	 * test FindCmd
	 */
	pNode = FindCmd(pMenu, cmd);
	if(pNode == NULL)
	{
		debug("error : FindCmd is failure !\n");
		result[7] = 0;
	}
	else
	{
		debug("FindCmd is success !\n");
		result[7] = 1;
	}
	/*
	 * test RunCmdHander
	 */
	temp = RunCmdHander(pMenu, pNode);
	if(temp == FAILURE)
	{
		debug("error : RunCmdHander is failure !\n");
		result[8] = 0;
	}
	else
	{
		debug("RunCmdHander is success !\n");
		result[8] = 1;
	}
	/*
	 * print TestCase report
	 */
	printf("TestCase report :\n");
	printf("\n");
	for(j = 1; j <= FUNC_NUM; j++)
	{
		if(result[j] == 0)
		{
			printf("TestCase Number %d F - %s\n", j, info[j]);
		}
	}
	printf("\n");
	for(j = 1; j <= FUNC_NUM; j++)
	{
		if(result[j] == 1)
		{
			printf("TestCase Number %d T - %s\n", j, info[j]);
		}
	}
	
	return 0;
}
