use cmd "make" todo
	gcc menu.h menu.c linktable.h linktable.c testmenu.c -o test

finaly,
	./test
