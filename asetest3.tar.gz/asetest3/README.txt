编译时使用“make”作为编译指令，相当于“gcc menu.h menu.c linktable.h linktable.c test.c -o test”
然后输入./test运行程序

文件夹除了本readme包括其他6个文件：linktable.c linktable.h menu.c menu.h test.c 以及Makefile文件；
测试用例一共为8个：
        "Test1: CreateMenu",
	"Test2: AddCmd",
	"Test3: DelCmd",
	"Test4: MenuStart",
	"Test5: DeleteMenu",
	"Test6: ShowAllCmd",
	"Test7: FindCmd",
	"Test8: RunCmdHander"
其中在我的程序menu.c中实现的 1 2 3 5 6，所以这几个测试值是成功的，其它3个为老师上课讲到的，但我的menu.c并未实现该功能，所以测试值为失败。test.c中初始化了一组命令：cmd=“testcmd”，desc=“this is a test cmd”，将该组命令作为测试值输入到每个实现函数里，用数组rep[]记录测试结果，成功rep值为1，失败为0.最后打印出测试结果。
注意 默认menu为空，里面没有指令，所以会看到初始化的空菜单。
感谢你的批改，如有任何问题请联系QQ：244872839 ：）
