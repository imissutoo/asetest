#include <stdio.h>
#include <stdlib.h>
#include "menu.h"

#define FUNC_NUM	8
#define RESULT_NUM	8
#define debug 

static char * rep[FUNC_NUM+1] =
{
	"All Test List :" ,
	"Test1: CreateMenu",
	"Test2: AddCmd",
	"Test3: DelCmd",
	"Test4: MenuStart",
	"Test5: DeleteMenu",
	"Test6: ShowAllCmd",
	"Test7: FindCmd",
	"Test8: RunCmdHander"
};

static int result[RESULT_NUM];

int main()
{
	int temp = 0;
        int i;
	char * cmd = "testcmd";
	char * desc = "this is a test cmd";
    
	tCmdNode * pNode;
	/*
	 * CreateMenu() TEST
	 */
	tLinkTable * pMenu = CreateMenu();
	if(pMenu == NULL)
	{
		debug("error : CreateMenu is failure !\n");
		result[1] = 0;
	}
	else
	{
		debug("CreateMenu is success !\n");
		result[1] = 1;
	}
	/*
	 * AddCmd() TEST
	 */
	temp = AddCmd(pMenu, cmd, desc);
	if(temp == FAILURE)
	{
		debug("error : AddCmd is failure !\n");
		result[2] = 0;
	}
	else
	{
		debug("AddCmd is success !\n");
		result[2] = 1;
	}
	/*
	 * DelCmd() TEST
	 */
	temp = DelCmd(pMenu, cmd);
	if(temp == FAILURE)
	{
		debug("error : DelCmd is failure !\n");
		result[3] = 0;
	}
	else
	{
		debug("DelCmd is success !\n");
		result[3] = 1;
	}
	/*
	 * MenuStart() TEST
	 */
	temp = MenuStart(pMenu);
	if(temp == FAILURE)
	{
		debug("error : MenuStart is failure !\n");
		result[4] = 0;
	}
	else
	{
		debug("MenuStart is success !\n");
		result[4] = 1;
	}
	/*
	 * DeleteMenu() TEST
	 */
	temp = DeleteMenu(pMenu);
	if(temp == FAILURE)
	{
		debug("error : DeleteMenu is failure !\n");
		result[5] = 0;
	}
	else
	{
		debug("DeleteMenu is success !\n");
		result[5] = 1;
	}
	/*
	 * ShowAllCmd() TEST
	 */
	temp = ShowAllCmd(pMenu);
	if(temp == FAILURE)
	{
		debug("error : ShowAllCmd is failure !\n");
		result[6] = 0;
	}
	else
	{
		debug("ShowAllCmd is success !\n");
		result[6] = 1;
	}
	/*
	 * FindCmd() TEST
	 */
	pNode = FindCmd(pMenu, cmd);
	if(pNode == NULL)
	{
		debug("error : FindCmd is failure !\n");
		result[7] = 0;
	}
	else
	{
		debug("FindCmd is success !\n");
		result[7] = 1;
	}
	/*
	 * RunCmdHander() TEST
	 */
	temp = RunCmdHander(pMenu, pNode);
	if(temp == FAILURE)
	{
		debug("error : RunCmdHander is failure !\n");
		result[8] = 0;
	}
	else
	{
		debug("RunCmdHander is success !\n");
		result[8] = 1;
	}
	/*
	 * print test report
	 */
    printf("Test report :\n\n");
    printf("***********************************\n");

	for(i = 1; i <= FUNC_NUM; i++)
	{
		if(result[i] == 0)
		{
			printf("Test %d Failure - %s\n", i, rep[i]);
		}

		if(result[i] == 1)
		{
			printf("Test %d Success - %s\n", i, rep[i]);
		}
	}
	
	return 0;
}
