
/************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014-2015                                    */
/*                                                                                  */
/*  FILE NAME             :  menu.c                                                 */
/*  PRINCIPAL AUTHOR      :  LiuYiming                                               */
/*  SUBSYSTEM NAME        :  menu                                                   */
/*  MODULE NAME           :  menu                                                   */
/*  LANGUAGE              :  C                                                      */
/*  TARGET ENVIRONMENT    :  ANY                                                    */
/*  DATE OF FIRST RELEASE :  2014/09/19                                             */
/*  DESCRIPTION           :  This is a menu program                                 */
/************************************************************************************/

/*
 *Revision log:
 *
 *Created by Liu Yiming, 2014/9/19
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "linktable.h"
#include "menu.h"

#define CMD_MAX_NUM	128
#define DESC_MAX_NUM	128
/*
 * print menu list
 */
int ShowAllCmd(tLinkTable * pLinkMenu);
/*
 * find cmd
 */
tCmdNode * FindCmd(tLinkTable * pLinkMenu, char *cmd);
/*
 * run cmd
 */
int RunCmdHander(tLinkTable * pLinkMenu, tCmdNode * pNode);
/*
 * create menu
 */
tLinkTable * CreateMenu()
{
	tLinkTable * pMenu = (tLinkTable *)malloc(sizeof(tLinkTable));
	if(pMenu == NULL)
	{
		return NULL;
	}

	return pMenu;
}
/*
 * add cmd
 */
int AddCmd(tLinkTable * pLinkMenu, char * cmd, char * desc)
{
	int temp = 0;
	if((pLinkMenu == NULL)||(cmd == NULL)||(desc == NULL))
	{
		return FAILURE;
	}
	tCmdNode * pCmdNode = (tCmdNode *)malloc(sizeof(tCmdNode));
	strcpy(pCmdNode->cmd, cmd);
	strcpy(pCmdNode->desc, desc);
	temp = AddLinkTableNode(pLinkMenu, (tLinkTableNode *)pCmdNode);

	return temp;
}
/*
 * delete cmd
 */
int DelCmd(tLinkTable * pLinkMenu, char * cmd)
{
	int temp = 0;
	if((pLinkMenu == NULL)||(cmd == NULL))
	{
		return FAILURE;
	}
	tCmdNode * pNode = FindCmd(pLinkMenu, cmd);
	if(pNode == NULL)
	{
		printf("Cmd is not existed!\n");
		return FAILURE;
	}
	temp = DelLinkTableNode(pLinkMenu, (tLinkTableNode * )pNode);
	return temp;
	
}
/*
 * start menu
 */
int MenuStart(tLinkTable * pLinkMenu)
{
	int temp = 0;
	char * cmd = "l";
	if(pLinkMenu == NULL)
	{	
		return FAILURE;
	}
	tCmdNode *p = FindCmd(pLinkMenu, cmd);
	if(p == NULL)
	{
		debug("This is a wrong cmd!\n");
	}
	temp = RunCmdHander(pLinkMenu, p);
	
	return temp;
}
/*
 * delete menu
 */
int DeleteMenu(tLinkTable * pLinkMenu)
{
	int temp = 0;
	if(pLinkMenu == NULL)
	{	
		printf("error : tLinkTable is NULL !\n");
		return FAILURE;
	}
	temp = DeleteLinkTable(pLinkMenu);
	return temp;
}

int ShowAllCmd(tLinkTable * pLinkMenu)
{
	if(pLinkMenu == NULL)
	{
		return FAILURE;
	}
	printf("*****************************************\n");
	printf("Menu List:				 \n");
	printf("					 \n");
	printf("*****************************************\n");
	return SUCCESS;
}
/*
 * find a cmd
 */
tCmdNode * FindCmd(tLinkTable * pLinkMenu, char *cmd)
{
	if((pLinkMenu == NULL)||(cmd == NULL))
	{
		return NULL;
	}
	tCmdNode *pNode = (tCmdNode *)GetLinkTableHead(pLinkMenu);

	while(pNode != NULL)
	{
		if(!strcmp(pNode->cmd, cmd))
		{
			return pNode;
			
		}
		pNode = (tCmdNode *)GetNextLinkTableNode(pLinkMenu,(tLinkTableNode *)pNode);
	}
	
	return NULL;
}
int RunCmdHander(tLinkTable * pLinkMenu, tCmdNode * pNode)
{
	if((pLinkMenu == NULL)||(pNode == NULL))
	{
		return FAILURE;
	}
	if(pNode->hander == NULL)
	{
		return FAILURE;
	}
	pNode->hander(pLinkMenu);
	return SUCCESS;
}
